package com.directi.training.codesmells.smelly.pieces;

import com.directi.training.codesmells.smelly.Color;

public class LeftRook extends Rook
{
    public LeftRook(Color color)
    {
        super(color);
    }
}
